import React, { Component } from 'react';
import './App.css';
const DispLine=()=>{
    return ( 
        <hr></hr>
    );
}
export default DispLine;